# RobustIDPS BlueSec practice pack

Investigation tasks built from public attack telemetry, in the evidence-graph
form used by the BlueSec competition runtime (entities and typed relations).
Created 2026-10-11T00:42:26Z.

| Task | Platform | Verdict | ATT&CK | Alert | Entities / relations |
|---|---|---|---|---|---|
| lsass-dump-comsvcs | windows | malicious | T1003.001 | Process opened LSASS with full access | 88 / 115 |
| logon-script-persistence | windows | malicious | T1037.001 | User environment registry value written by reg.exe | 47 / 75 |
| service-binpath-hijack | windows | malicious | T1543.003 | Service configuration changed with sc.exe | 157 / 219 |
| hta-startup-folder | windows | malicious | T1218.005 | mshta.exe executed an HTA file | 338 / 717 |
| firewall-rule-added | windows | malicious | T1562.004 | Inbound firewall rule added from the command line | 174 / 365 |
| python-http-server | windows | malicious | T1059 | Interpreter from a user profile started a network service | 300 / 633 |
| bits-download | windows | malicious | T1197 | BITS transfer job started from the command line | 186 / 247 |
| run-key-and-beacon | windows | malicious | T1547.001 | Autostart Run key value set by PowerShell | 74 / 87 |
| lsass-query-by-svchost | windows | benign | - | Process opened a handle to LSASS | 186 / 247 |
| w32time-runtime-key | windows | benign | - | Registry value written under a path matching '\Run' | 300 / 633 |
| gpsvc-service-host | windows | benign | - | New service host process started as SYSTEM | 174 / 365 |
| linux-shadow-read | linux | malicious | T1003.008 | Credential file read by a script run with sudo | 50 / 76 |
| linux-wiper-shred | linux | malicious | T1485 | shred overwrote a system directory | 317 / 672 |
| linux-kernel-module | linux | malicious | T1547.006 | Kernel module loaded with insmod | 78 / 142 |
| linux-account-created | linux | malicious | T1136.001 | Local account created | 76 / 127 |
| linux-sudoers-nopasswd | linux | malicious | T1548.003 | Passwordless sudo rule written | 141 / 245 |
| linux-ld-preload-hijack | linux | malicious | T1574.006 | Freshly compiled binary executed as root from a home directory | 150 / 265 |
| linux-service-stopped | linux | malicious | T1489 | Service state changed by systemctl as root | 1602 / 3951 |
| linux-dpkg-service-start | linux | benign | - | Service state changed by systemctl as root | 1602 / 3951 |
| linux-motd-discovery | linux | benign | - | Session discovery command run as root | 317 / 672 |
| linux-motd-tmp-cleanup | linux | benign | - | Files deleted by rm as root | 317 / 672 |

## Run it

    uv run --with anthropic --with jsonschema --env-file .env \
        python -m bluesec1_agent.robust.cli --pack this-pack.zip --concurrency 4

Then import the run folder on robustidps.ai > BlueSec Runs.

## How it was built

- Windows: OTRF Security-Datasets (Open Threat Research Forge, MIT licence),
  Sysmon and Windows Security events recorded during ATT&CK technique
  simulations.
- Linux: Splunk attack_data (Splunk, Apache-2.0), Sysmon for Linux events
  recorded in Splunk Attack Range. The log forwarder's own checkpoint-file
  writes under /opt/splunkforwarder were removed as collector self-telemetry.
- Events were converted into entities (processes, files, registry keys,
  connections, users, hosts) and relations (process creation, file write,
  registry write, connect, process access, ...). Field values are copied
  from the source events, capped at 600 characters.
- Malicious tasks: the operator's recorded session is the root of the
  activity. Benign tasks: real background events from the same recordings
  that a naive rule would flag.

Sources:
- OTRF Security-Datasets `SDWIN-200722001847`: https://raw.githubusercontent.com/OTRF/Security-Datasets/master/datasets/atomic/windows/persistence/host/empire_persistence_registry_modification_run_keys_elevated_user.zip
- OTRF Security-Datasets `SDWIN-201018195009`: https://raw.githubusercontent.com/OTRF/Security-Datasets/master/datasets/atomic/windows/credential_access/host/psh_lsass_memory_dump_comsvcs.zip
- OTRF Security-Datasets `SDWIN-201019224718`: https://raw.githubusercontent.com/OTRF/Security-Datasets/master/datasets/atomic/windows/persistence/host/cmd_userinitmprlogonscript_batch.zip
- OTRF Security-Datasets `SDWIN-201021001911`: https://raw.githubusercontent.com/OTRF/Security-Datasets/master/datasets/atomic/windows/defense_evasion/host/cmd_netsh_fw_mod_open_ports.zip
- OTRF Security-Datasets `SDWIN-201021204544`: https://raw.githubusercontent.com/OTRF/Security-Datasets/master/datasets/atomic/windows/privilege_escalation/host/cmd_service_mod_fax.zip
- OTRF Security-Datasets `SDWIN-201022035214`: https://raw.githubusercontent.com/OTRF/Security-Datasets/master/datasets/atomic/windows/defense_evasion/host/psh_mshta_html_application_execution.zip
- OTRF Security-Datasets `SDWIN-201023023651`: https://raw.githubusercontent.com/OTRF/Security-Datasets/master/datasets/atomic/windows/defense_evasion/host/cmd_bitsadmin_download_psh_script.zip
- OTRF Security-Datasets `SDWIN-201029001615`: https://raw.githubusercontent.com/OTRF/Security-Datasets/master/datasets/atomic/windows/execution/host/psh_python_webserver.zip
- Splunk attack_data `T1003.008/copy_file_stdoutpipe`: https://media.githubusercontent.com/media/splunk/attack_data/master/datasets/attack_techniques/T1003.008/copy_file_stdoutpipe/sysmon_linux.log
- Splunk attack_data `T1485/rm_shred_critical_dir`: https://media.githubusercontent.com/media/splunk/attack_data/master/datasets/attack_techniques/T1485/rm_shred_critical_dir/sysmon_linux.log
- Splunk attack_data `T1489/linux_service_stop_disable`: https://media.githubusercontent.com/media/splunk/attack_data/master/datasets/attack_techniques/T1489/linux_service_stop_disable/sysmon_linux.log
- Splunk attack_data `T1547.006/loading_linux_kernel_module`: https://media.githubusercontent.com/media/splunk/attack_data/master/datasets/attack_techniques/T1547.006/loading_linux_kernel_module/sysmon_linux.log
- Splunk attack_data `T1548.003/linux_adduser`: https://media.githubusercontent.com/media/splunk/attack_data/master/datasets/attack_techniques/T1548.003/linux_adduser/sysmon_linux.log
- Splunk attack_data `T1548.003/nopasswd_sudoers`: https://media.githubusercontent.com/media/splunk/attack_data/master/datasets/attack_techniques/T1548.003/nopasswd_sudoers/sysmon_linux.log
- Splunk attack_data `T1574.006/lib_hijack`: https://media.githubusercontent.com/media/splunk/attack_data/master/datasets/attack_techniques/T1574.006/lib_hijack/sysmon_linux.log

## Scoring (RobustIDPS, not the competition's)

Quality = half verdict, half artifacts. Malicious: F1 of recall over `core`
(full credit for a fitting response kind, half for another kind) and
precision against `acceptable`. Benign: share of `evidence_fields` anchors
cited with a decisive property field. Wrong verdict = 0.
Efficiency = min(1, (optimal_calls + 1) / tool calls).
Reward = quality x (0.8 + 0.2 x efficiency).

`answers/` holds the ground truth. Keep it away from the agent under test.
